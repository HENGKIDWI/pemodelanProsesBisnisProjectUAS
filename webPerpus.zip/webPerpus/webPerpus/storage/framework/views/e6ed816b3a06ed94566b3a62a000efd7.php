<!DOCTYPE html>
<html>
<head>
    <title>Bebas Tanggungan Perpustakaan</title>
</head>
<body>
    <h3>Halo, <?php echo e($user->name); ?>!</h3>
    
    <p>Permohonan bebas tanggungan perpustakaan Anda telah <strong>DISETUJUI</strong>.</p>
    
    <p>Terlampir adalah Surat Bebas Tanggungan Perpustakaan resmi dalam format PDF. Silakan unduh dan simpan file tersebut sebagai syarat administrasi selanjutnya.</p>
    
    <p>Terima kasih,<br>
    Tim Perpustakaan UTM</p>
</body>
</html><?php /**PATH C:\laragon\www\kontol_jepat\pemodelanProsesBisnisProjectUAS\webPerpus\webPerpus\resources\views/emails/surat-bebas.blade.php ENDPATH**/ ?>