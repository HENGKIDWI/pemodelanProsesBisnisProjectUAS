<div style="color: white" class="text-center font-bold">
   <span class="text-3xl">PERPUSTAKAAN UTM</span>
</div><?php /**PATH C:\laragon\www\kontol_jepat\pemodelanProsesBisnisProjectUAS\webPerpus\webPerpus\resources\views/components/application-logo.blade.php ENDPATH**/ ?>