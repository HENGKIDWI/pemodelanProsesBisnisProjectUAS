<div style="color: white" class="text-center font-bold">
   <span class="text-3xl">PERPUSTAKAAN UTM</span>
</div>